package com.codingshuttle.youtube.hospitalManagement.entity.type;

public enum RoleType {
    ADMIN,
    DOCTOR,
    PATIENT
}
